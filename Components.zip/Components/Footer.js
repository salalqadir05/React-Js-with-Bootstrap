import React from 'react'

export default function Footer() {
  return (
    <>
         <footer className="container mt-2">
        <p className="float-end"><a href="#">Back to top</a></p>
        <p>© 2022–2023 Company, Inc. · <a href="#">Privacy</a> · <a href="#">Terms</a></p>
      </footer> 
    </>
  )
}
