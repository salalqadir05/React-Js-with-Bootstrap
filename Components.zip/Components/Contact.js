import React from 'react'

export default function Contact() {
    const alertmessage =() =>{
alert("You Have Submitted Your Response");
   }


  return (
    <>
       <div className="container mx-5 mt-4 ">
        <div className="mb-3 mx-5">
            <label htmlFor="exampleFormControlInput1" className="form-label">Email address</label>
            <input type="email" className="form-control w-50" placeholder='Enter Your Email' id="exampleFormControlInput1" />
          </div>
          <div className="mb-3 mx-5">
            <label htmlFor="exampleFormControlTextarea1" className="form-label ">Write SomeThing</label>
            <textarea className="form-control w-50" placeholder='Enter Here' id="exampleFormControlTextarea1" rows="6"></textarea>
          </div>
          <button className="btn btn-outline-primary mx-5 mt-1"  onClick={alertmessage}>Submit</button>
          
    </div>
    </>
  )
}
