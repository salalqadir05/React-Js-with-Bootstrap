import React from 'react'

export default function About() {
  return (
    <>
     
    <div className="container my-5">
        <div className="row featurette d-flex justify-content-center align-items-center">
            <div className="col-md-7 order-md-2">
                <h2 className="featurette-heading d-flex justify-content-center align-items-center">Oh yeah, it s that good.
                    <span className="text-muted">See for yourself.</span></h2>
                <p className="lead">Another featurette? Of course. More placeholder content here to give you an idea of howclass=
                    this layout would work with some actual real-world content in place.</p>
            </div>
            <div className="col-md-5 order-md-1">
                <img src="https://source.unsplash.com/400x400/?coding" alt="Image" className="img-fluid" />
            </div>
        </div>
        <div className="row mt-5 featurette d-flex justify-content-center align-items-center">
            <div className="col-md-7 order-md-1">
                <h2 className="featurette-heading d-flex justify-content-center align-items-center">Oh yeah, it s that good.
                    <span className="text-muted">See for yourself.</span></h2>
                <p className="lead">Another featurette? Of course. More placeholder content here to give you an idea of how
                    this layout would work with some actual real-world content in place.</p>
            </div>
            <div className="col-md-5 order-md-2">
                <img src="https://source.unsplash.com/400x400/?technology" alt="Image" className="img-fluid" />
            </div>
        </div>
        <div className="row mt-5 featurette d-flex justify-content-center align-items-center">
            <div className="col-md-7 order-md-2">
                <h2 className="featurette-heading d-flex justify-content-center align-items-center">Oh yeah, it s that good.
                    <span className="text-muted">See for yourself.</span></h2>
                <p className="lead">Another featurette? Of course. More placeholder content here to give you an idea of how
                    this layout would work with some actual real-world content in place.</p>
            </div>
            <div className="col-md-5 order-md-1">
                <img src="https://source.unsplash.com/400x400/?coding,technology" alt="Image" className="img-fluid" />
            </div>
        </div>
    </div> 
    </>
  )
}
