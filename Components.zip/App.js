// import logo from './logo.svg';
import './App.css';
import Footer from "./Components/Footer";
import NavBar from "./Components/NavBar";
import Slider from "./Components/Slider";
import Home from "./Components/Home";
import About from "./Components/About";
import Contact from "./Components/Contact";


import React, { useState } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Link,
  Switch
} from 'react-router-dom';
function App() {
  return (

      <Router>
        <NavBar />
        <Slider />
        <Routes>
          
         <Route path='/' element={ <Home />} />
         <Route path='/About' element={ <About />} />
         <Route path='/Contact' element={ <Contact />} />


        </Routes>
        <Footer />
        </Router >





      );
}

      export default App;
